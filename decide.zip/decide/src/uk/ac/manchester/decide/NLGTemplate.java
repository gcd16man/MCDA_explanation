package uk.ac.manchester.decide;
/* 
 *  NLGTemplate.java
 *
 * Implementation of template-based NLG component
 *
 */
//import simplenlg.org.junit.Ignore;
import simplenlg.features.*;
import simplenlg.framework.*;
import simplenlg.lexicon.Lexicon;
import simplenlg.lexicon.XMLLexicon;
import simplenlg.phrasespec.AdjPhraseSpec;
import simplenlg.phrasespec.NPPhraseSpec;
import simplenlg.phrasespec.VPPhraseSpec;
import simplenlg.phrasespec.PPPhraseSpec;
import simplenlg.phrasespec.SPhraseSpec;
import simplenlg.realiser.english.Realiser;

import java.util.ArrayList;
import java.lang.StringBuffer;

public class NLGTemplate {

    private String templateId = null;
 
     public void setTemplateId(String id) {
	this.templateId = id;
    }

    public String getTemplateId() {
    return this.templateId;
  }

    private static ArrayList<Criterion> getImportanceType(ArrayList<Criterion> criteria,
							  String importance){
	ArrayList<Criterion> criteriaSublist = new ArrayList<Criterion>();
	for (int i = 0; i < criteria.size(); i++) { 		      
	    Criterion c = criteria.get(i);
	    if(c.getImportance().equals(importance)) {
		criteriaSublist.add(c);
	    }
	    }
	
	return criteriaSublist;
    }
    // template 1
    public static String runTemplate(ArrayList<Criterion> criteria,
				     String importantCriterion,
				     String WorstOutcomeImportantCriteriaRange,
				     String BestOutcomeImportantCriteriaRange,
				     String lessImportantCriterion,
				     String WorstOutcomeLessImportantCriteriaRange,
				     String BestOutcomeLessImportantCriteriaRange) {

	StringBuffer finalOutput = new StringBuffer();
	
	Lexicon lexicon = new XMLLexicon();                          // default simplenlg lexicon
	NLGFactory nlgFactory = new NLGFactory(lexicon);             // factory based on lexicon
	Realiser r = new Realiser(); // set up realiser
	
	// create sentences
	// e.g. "You have rated the following criteria as highly important: Accessibility from US and Private sector. Whilst Availability of staff, Quality of life and Public sector are criteria considered to be of medium importance, Ease of set up and operations is of low importance"
	/*
	SPhraseSpec s1 = new SPhraseSpec(nlgFactory);
	s1.setSubject("you");
	s1.setVerb("rate");
	s1.addComplement("criteria");
	s1.setTense(Tense.PAST);
	s1.setFeature(Feature.PASSIVE);
	

	//	String output = r.realiseSentence(s1); // generate text
	
	//	SPhraseSpec s2 = new SPhraseSpec(nlgFactory);
	ArrayList<Criterion> criteriaHigh = getImportanceType(criteria, "high");
	for (int i = 0; i < criteriaHigh.size(); i++) {
	    Criterion c = criteriaHigh.get(i);
	    String name = c.getName();
	    if (i==criteriaHigh.size()-1) {s1.addComplement("and");}
	    s1.addComplement(name);
	}
	*/

	//s1("You have rated the following criteria as highly important");
	ArrayList<Criterion> criteriaHigh = getImportanceType(criteria, "high");
	
	NPPhraseSpec subjectNP = nlgFactory.createNounPhrase("you");
	VPPhraseSpec verbP = nlgFactory.createVerbPhrase("rate");
	verbP.setTense(Tense.PAST);
	verbP.addPreModifier("have");
	NPPhraseSpec objectNP;
	if (criteriaHigh.size()>1) {
	    objectNP = nlgFactory.createNounPhrase("criteria");
	}
	else {objectNP = nlgFactory.createNounPhrase("criterion");}
	objectNP.setDeterminer("the");
	objectNP.addModifier("following");
	PPPhraseSpec phrasePP = nlgFactory.createPrepositionPhrase("as", "highly important");
	SPhraseSpec p = nlgFactory.createClause();
	p.setSubject(subjectNP);
	p.setVerbPhrase(verbP);
	p.setObject(objectNP);
        p.addModifier(phrasePP);
	String output = r.realiseSentence(p); // generate text 	 

	System.out.println(output); // print out the text

	//s2 ("Accessibility from US and Private sector.");
	p = nlgFactory.createClause();
	CoordinatedPhraseElement subj = nlgFactory.createCoordinatedPhrase();

	for (int i = 0; i < criteriaHigh.size(); i++) {
	    Criterion c = criteriaHigh.get(i);
	    String name = c.getName();
	    if (i==criteriaHigh.size()-1) {subj.addComplement("and");}
	    else if (i>0) {subj.addComplement(",");}
	    NPPhraseSpec np = nlgFactory.createNounPhrase(name);
	    subj.addComplement(np);
	    
    }
	p.setSubject(subj);
	output = r.realiseSentence(p); // generate text 	 

	System.out.println(output); // print out the text

	//s3("Whilst Availability of staff, Quality of life and Public sector are criteria considered to be of medium importance, Ease of set up and operations is of low importance")
	ArrayList<Criterion> criteriaMedium = getImportanceType(criteria, "med");
	p = nlgFactory.createClause();
	verbP = nlgFactory.createVerbPhrase("be");
	if (criteriaMedium.size()>1) {
	    verbP.setPlural(true);
	    objectNP = nlgFactory.createNounPhrase("criteria");
	}
	else {
	    objectNP = nlgFactory.createNounPhrase("criterion");
	}
	
	objectNP.setPostModifier("considered to be");
	phrasePP = nlgFactory.createPrepositionPhrase("of", "medium importance,");
	
	subj = nlgFactory.createCoordinatedPhrase();
	
	for (int i = 0; i < criteriaMedium.size(); i++) {
	    Criterion c = criteriaMedium.get(i);
	    String name = c.getName();
	    if (i==0) {subj.addPreModifier("whilst");}
	    if (i==criteriaMedium.size()-1) {subj.addComplement("and");}
	    else if (i>0) {subj.addComplement(",");}
	    NPPhraseSpec np = nlgFactory.createNounPhrase(name);
	    subj.addComplement(np);
	    
    }
	p.setSubject(subj);
	p.setVerb(verbP);
	p.setObject(objectNP);
	p.addModifier(phrasePP);

	// low importance
	ArrayList<Criterion> criteriaLow = getImportanceType(criteria, "low");
	
	CoordinatedPhraseElement obj2 = nlgFactory.createCoordinatedPhrase();
	phrasePP = nlgFactory.createPrepositionPhrase("of", "low importance");

	for (int i = 0; i < criteriaLow.size(); i++) {
	    Criterion c = criteriaLow.get(i);
	    String name = c.getName();
	
	    NPPhraseSpec np = nlgFactory.createNounPhrase(name);
	    obj2.addComplement(np);
	    System.out.println("i="+ i + " name="+ name);
	        if (criteriaLow.size()>1 && i==criteriaLow.size()-1) {obj2.addComplement("and");}
		else if (criteriaLow.size()>1 && i>1) {obj2.addComplement(",");}
    }
	verbP = nlgFactory.createVerbPhrase("be");
	if (criteriaLow.size()>1) {
	    verbP.setPlural(true);
	   	}
	p.addModifier(obj2);
	p.addModifier(verbP);
	p.addModifier(phrasePP);
	output = r.realiseSentence(p); // generate text 	 

	System.out.println(output); // print out the text

	// s4("This implies that the ranges of outcomes for important criteria such as the Private sector from 42 units to 96 units (i.e. from the worst to the best outcome) are more influential for the current choice than the ranges of outcomes for other less important criteria e.g. from 30 units to 90 units of Ease of set up and operations.)

	p = nlgFactory.createClause();
	subjectNP = nlgFactory.createNounPhrase("");
	subjectNP.setDeterminer("this");
	verbP = nlgFactory.createVerbPhrase("imply");
	phrasePP = nlgFactory.createPrepositionPhrase("that", "the ranges of outcomes such as");
	p.setSubject(subjectNP);
	p.setVerbPhrase(verbP);	
        p.addModifier(phrasePP);
	NPPhraseSpec bc = nlgFactory.createNounPhrase(importantCriterion);
	bc.setDeterminer("the");
	p.addModifier(bc);
	PPPhraseSpec pp1 = nlgFactory.createPrepositionPhrase("from");
	p.addModifier(pp1);
	NPPhraseSpec woicr = nlgFactory.createNounPhrase(WorstOutcomeImportantCriteriaRange);
	p.addModifier(woicr);
	NPPhraseSpec units = nlgFactory.createNounPhrase("units");
	units.setPlural(true);
	p.addModifier(units);
    PPPhraseSpec pp2 = nlgFactory.createPrepositionPhrase("to");
	p.addModifier(pp2);
    NPPhraseSpec boicr = nlgFactory.createNounPhrase(BestOutcomeImportantCriteriaRange);
	p.addModifier(boicr);
    p.addModifier(units);
    StringElement se = new StringElement("(i.e. from the worst to the best outcome) are more influential for the current choice than the ranges of outcomes for other less important criteria e.g. from");
    p.addModifier(se);
    	NPPhraseSpec wolicr = nlgFactory.createNounPhrase(WorstOutcomeLessImportantCriteriaRange);
	p.addModifier(wolicr);
	p.addModifier(units);
	p.addModifier(pp2);
    NPPhraseSpec bolicr = nlgFactory.createNounPhrase(BestOutcomeLessImportantCriteriaRange);
	p.addModifier(bolicr);
    p.addModifier(units);
     PPPhraseSpec pp3 = nlgFactory.createPrepositionPhrase("of");
	p.addModifier(pp3);
	NPPhraseSpec lbc = nlgFactory.createNounPhrase(lessImportantCriterion);
	p.addModifier(lbc);
	output = r.realiseSentence(p); // generate text 	 

	System.out.println(output); // print out the text
	/*
		// e.g.	"John did not go to the bigger park. He played football there."
		NPPhraseSpec thePark = nlgFactory.createNounPhrase("the", "park");   // create an NP
		AdjPhraseSpec bigp = nlgFactory.createAdjectivePhrase("big");        // create AdjP
		bigp.setFeature(Feature.IS_COMPARATIVE, true);                       // use comparative form ("bigger")
		thePark.addModifier(bigp);                                        // add adj as modifier in NP
		// above relies on default placement rules.  You can force placement as a premodifier
		// (before head) by using addPreModifier
		PPPhraseSpec toThePark = nlgFactory.createPrepositionPhrase("to");    // create a PP
		toThePark.setObject(thePark);                                     // set PP object
		// could also just say nlgFactory.createPrepositionPhrase("to", the Park);

		SPhraseSpec johnGoToThePark = nlgFactory.createClause("John",      // create sentence
		                                                      "go", toThePark);

		johnGoToThePark.setFeature(Feature.TENSE, Tense.PAST);              // set tense
		johnGoToThePark.setFeature(Feature.NEGATED, true);                 // set negated

		// note that constituents (such as subject and object) are set with setXXX methods
		// while features are set with setFeature

		DocumentElement sentence = nlgFactory                            // create a sentence DocumentElement from SPhraseSpec
				.createSentence(johnGoToThePark);

		// below creates a sentence DocumentElement by concatenating strings
		StringElement hePlayed = new StringElement("he played");
		StringElement there = new StringElement("there");
		WordElement football = new WordElement("football");

		DocumentElement sentence2 = nlgFactory.createSentence();
		sentence2.addComponent(hePlayed);
		sentence2.addComponent(football);
		sentence2.addComponent(there);

		// now create a paragraph which contains these sentences
		DocumentElement paragraph = nlgFactory.createParagraph();
		paragraph.addComponent(sentence);
		paragraph.addComponent(sentence2);

		// create a realiser.  Note that a lexicon is specified, this should be
		// the same one used by the NLGFactory
		Realiser realiser = new Realiser(lexicon);
		//realiser.setDebugMode(true);     // uncomment this to print out debug info during realisation
		NLGElement realised = realiser.realise(paragraph);

		System.out.println(realised.getRealisation());

		// end of main example

		// second example - using simplenlg just for morphology
		// below is clumsy as direct access to morphology isn't properly supported in V4.2
		// hopefully will be better supported in later versions

		// get word element for "child"
		WordElement word = (WordElement) nlgFactory.createWord("child", LexicalCategory.NOUN);
		// create InflectedWordElement from word element
		InflectedWordElement inflectedWord = new InflectedWordElement(word);
		// set the inflected word to plural
		inflectedWord.setPlural(true);
		// realise the inflected word
		String result = realiser.realise(inflectedWord).getRealisation();
	
		System.out.println(result);
	return result;
	*/
	return output;
    }
    /*
    public String runTemplate(String id) {
			// set up
		Lexicon lexicon = new XMLLexicon();                          // default simplenlg lexicon
		NLGFactory nlgFactory = new NLGFactory(lexicon);             // factory based on lexicon

		// create sentences
		// 	"John did not go to the bigger park. He played football there."
		NPPhraseSpec thePark = nlgFactory.createNounPhrase("the", "park");   // create an NP
		AdjPhraseSpec bigp = nlgFactory.createAdjectivePhrase("big");        // create AdjP
		bigp.setFeature(Feature.IS_COMPARATIVE, true);                       // use comparative form ("bigger")
		thePark.addModifier(bigp);                                        // add adj as modifier in NP
		// above relies on default placement rules.  You can force placement as a premodifier
		// (before head) by using addPreModifier
		PPPhraseSpec toThePark = nlgFactory.createPrepositionPhrase("to");    // create a PP
		toThePark.setObject(thePark);                                     // set PP object
		// could also just say nlgFactory.createPrepositionPhrase("to", the Park);

		SPhraseSpec johnGoToThePark = nlgFactory.createClause("John",      // create sentence
		                                                      "go", toThePark);

		johnGoToThePark.setFeature(Feature.TENSE, Tense.PAST);              // set tense
		johnGoToThePark.setFeature(Feature.NEGATED, true);                 // set negated

		// note that constituents (such as subject and object) are set with setXXX methods
		// while features are set with setFeature

		DocumentElement sentence = nlgFactory                            // create a sentence DocumentElement from SPhraseSpec
				.createSentence(johnGoToThePark);

		// below creates a sentence DocumentElement by concatenating strings
		StringElement hePlayed = new StringElement("he played");
		StringElement there = new StringElement("there");
		WordElement football = new WordElement("football");

		DocumentElement sentence2 = nlgFactory.createSentence();
		sentence2.addComponent(hePlayed);
		sentence2.addComponent(football);
		sentence2.addComponent(there);

		// now create a paragraph which contains these sentences
		DocumentElement paragraph = nlgFactory.createParagraph();
		paragraph.addComponent(sentence);
		paragraph.addComponent(sentence2);

		// create a realiser.  Note that a lexicon is specified, this should be
		// the same one used by the NLGFactory
		Realiser realiser = new Realiser(lexicon);
		//realiser.setDebugMode(true);     // uncomment this to print out debug info during realisation
		NLGElement realised = realiser.realise(paragraph);

		System.out.println(realised.getRealisation());

		// end of main example

		// second example - using simplenlg just for morphology
		// below is clumsy as direct access to morphology isn't properly supported in V4.2
		// hopefully will be better supported in later versions

		// get word element for "child"
		WordElement word = (WordElement) nlgFactory.createWord("child", LexicalCategory.NOUN);
		// create InflectedWordElement from word element
		InflectedWordElement inflectedWord = new InflectedWordElement(word);
		// set the inflected word to plural
		inflectedWord.setPlural(true);
		// realise the inflected word
		String result = realiser.realise(inflectedWord).getRealisation();

		System.out.println(result);
    
	return result;
    
    return output;
    }
    */ 
}
