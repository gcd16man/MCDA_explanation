package uk.ac.manchester.decide;
/* 
 * NLGParameterReader.java
 */

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
/**
 *  NLGParamReader works with input a XML file specifying the
 *  set of parameters to be used for mapping to SimpleNLG grammar.
 *
 * The format of the XML parameter file is as in the following example:
 *  (please note: matching is *case-sensitive*)
 * 
 <?xml version="1.0" encoding="UTF-8"?>
 <Template id="1">
   <Parameters>
     <Parameter name="criterion" quality="importance" value="high">
 	<Entity>Accessibility from US</Entity>
     </Parameter>
     <Parameter name="criterion"  quality="importance" value="high">
 	<Entity>Private sector</Entity>
     </Parameter>
     <Parameter name="criterion"  quality="importance" value="medium">
 	<Entity>Quality of life</Entity>
     </Parameter> 
     <Parameter name="criterion"  quality="importance" value="low">
 	<Entity>Ease of set up</Entity>
     </Parameter> 
   </Parameters> 
 </Template>
 
 */
     
public class NLGParameterReader {
    /*   
  public static void main (String[] args){
      String inputFileURL = "C:/tmp/decide/data/parameters.xml";
      xmlParse(inputFileURL);
  }

    */

    private String inputFileURL;

    public static void setInputFilePath(String url) {
	//String inputFileURL = "C:/tmp/decide/data/parameters.xml";
	String inputFileURL = url;
	//xmlParse();
    }

    public String getInputFilePath() {
	    return this.inputFileURL;
	}
    
public static void xmlParse(String paramURL) {
 
    try {
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder = factory.newDocumentBuilder();
	Document document = builder.parse(new File(paramURL));

	document.getDocumentElement().normalize();
	//Here comes the root node i.e template
	Element root = document.getDocumentElement();
	System.out.println(root.getNodeName());

	String id = root.getAttribute("id");
	System.out.println("id="+id);
	 if (id.equals("1")) {
	     readParameters1(id, document);
	 } else if (id.equals("2")) {
	     readParameters2(id, document);
	 }

    } catch (Exception e) {
         e.printStackTrace();
    }
}

    //template type 1
    private static void readParameters1(String id,
				   org.w3c.dom.Document document) {
    if (id.equals("1")) {
    ArrayList<Criterion> criteria = new ArrayList<Criterion>();
    //Get the params
    NodeList nList = document.getElementsByTagName("Parameter");

    for (int temp = 0; temp < nList.getLength(); temp++){
	Node node = nList.item(temp);
	Element e = (Element)node;
	// get the name, quality and value attrs
	String name  = e.getAttribute("name");
	String quality = e.getAttribute("quality");
	String value = e.getAttribute("value");
	System.out.println("Name="+name+" quality="+quality+" value="+value);
	
	// get child entities
	NodeList classChildNodeList = node.getChildNodes();

	String elementName  = null;
       	
	    for(int j=0; j<classChildNodeList.getLength(); j++) {
	
               org.w3c.dom.Node childNode = classChildNodeList.item(j);
	       elementName = childNode.getNodeName();

	       if (childNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {

			Element eElement = (Element) childNode;
			Text elText = (Text) eElement.getFirstChild();
			String theValue = elText.getNodeValue().trim();
			
			if (elementName.equals("Entity")) {
			    // fill the template object class
			    //System.out.println("Entity="+theValue);
			    if (name.equals("criterion")) {
				    Criterion crit = new Criterion();
				    crit.setName(theValue);
				    if (quality.equals("importance")) {
					crit.setImportance(value);
				    }
				    // add to criteria list
				    criteria.add(crit);
			    }
			}		
	       }
	    }	   
    }

    String importantCriterion = null;
    String WorstOutcomeImportantCriteriaRange = null;
    String BestOutcomeImportantCriteriaRange = null;
    String lessImportantCriterion = null;
    String WorstOutcomeLessImportantCriteriaRange = null;
    String BestOutcomeLessImportantCriteriaRange = null;
    
    nList = document.getElementsByTagName("ImportantCriterion");
    Node node = nList.item(0);
    Element e = (Element)node;
    Text elText = (Text) e.getFirstChild();
    importantCriterion = elText.getNodeValue().trim();
    
    nList = document.getElementsByTagName("WorstOutcomeImportantCriteriaRange");
    node = nList.item(0);
    e = (Element)node;
    elText = (Text) e.getFirstChild();
    WorstOutcomeImportantCriteriaRange = elText.getNodeValue().trim();

    nList = document.getElementsByTagName("BestOutcomeImportantCriteriaRange");
    node = nList.item(0);
    e = (Element)node;
    elText = (Text) e.getFirstChild();
    BestOutcomeImportantCriteriaRange = elText.getNodeValue().trim();

    nList = document.getElementsByTagName("LessImportantCriterion");
    node = nList.item(0);
    e = (Element)node;
    elText = (Text) e.getFirstChild();
    lessImportantCriterion = elText.getNodeValue().trim();
    
    nList = document.getElementsByTagName("WorstOutcomeLessImportantCriteriaRange");
    node = nList.item(0);
    e = (Element)node;
    elText = (Text) e.getFirstChild();
    WorstOutcomeLessImportantCriteriaRange = elText.getNodeValue().trim();

    nList = document.getElementsByTagName("BestOutcomeLessImportantCriteriaRange");
    node = nList.item(0);
    e = (Element)node;
    elText = (Text) e.getFirstChild();
    BestOutcomeLessImportantCriteriaRange = elText.getNodeValue().trim();
    
   System.out.println("Important criterion="+importantCriterion
		       +" WorstOutcomeImportantCriteriaRange="+ WorstOutcomeImportantCriteriaRange
		       +" BestOutcomeImportantCriteriaRange="+ BestOutcomeImportantCriteriaRange
		       +" Less important criterion="+lessImportantCriterion
		       +" WorstOutcomeLessImportantCriteriaRange="+WorstOutcomeLessImportantCriteriaRange
		       +" BestOutcomeLessImportantCriteriaRange="+BestOutcomeLessImportantCriteriaRange);
   
    // sort list of criteria according to importance
	       if (!criteria.isEmpty()) {
		   System.out.println(criteria.size());
		   Collections.sort(criteria, (o1, o2) -> o1.getImportanceScale() - o2.getImportanceScale());
		   NLGTemplate template = new NLGTemplate();
		   template.setTemplateId(id);
		   template.runTemplate(criteria,
		   importantCriterion,
		   WorstOutcomeImportantCriteriaRange,
		   BestOutcomeImportantCriteriaRange,
		   lessImportantCriterion,
		   WorstOutcomeLessImportantCriteriaRange,
		   BestOutcomeLessImportantCriteriaRange			);
	       }
    }
    }
        private static void readParameters2(String id,
				   org.w3c.dom.Document document) {
	}
}
