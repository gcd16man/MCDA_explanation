package uk.ac.manchester.decide;
/* 
 *  Importance.java
 *
 * Implementation of NLG component
 *
 */

public class Importance {
    private String value = null;
    
    private int ord = 0;
    
    public void setValue(String imp) {
	this.value = imp;
	if (value.equals("high")) {ord=3;}
	else if (value.equals("medium")) {ord=2;}
	else if (value.equals("low")) {ord=1;}
    }

    public String getValue() {
    return this.value;
  }   
}

    
/*
import java.util.ArrayList;

public class Importance {
    private String importance = null;
    private String upperRange = null;
    private String lowerRange = null;
    private ArrayList<String> criteria = new ArrayList<String>(); 

    public void setImportance(String imp) {
	this.importance = imp;
    }

    public String getImportance() {
    return this.importance;
  }
    
    public void setCriteria(ArrayList<String> c) {
	this.criteria = c;
    }

    public ArrayList<String> getCriteria() {
	return this.criteria;
  }
    public void setUpperRange(String ur) {
	this.upperRange = ur;
    }

    public String getUpperRange() {
	return this.upperRange;
  }
       public void setLowerRange(String lr) {
	this.lowerRange = lr;
    }

    public String getLowerRange() {
	return this.lowerRange;
  }
}
*/
