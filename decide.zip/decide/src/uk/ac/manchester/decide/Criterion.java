package uk.ac.manchester.decide;
/* 
 *  Criterion.java
 *
 * Implementation of NLG component
 *
 */

public class Criterion {
    private String name = null;

    private String importance = null;

    private int importanceScale = 0;
    
    public void setName(String imp) {
	this.name = imp;
	System.out.println("name="+imp);
    }

    public String getName() {
    return this.name;
  }
    
    public void setImportance(String imp) {
	this.importance = imp;
	if (importance.equals("high")) {importanceScale=1;}
	else if (importance.equals("medium")) {importanceScale=2;}
	else if (importance.equals("low")) {importanceScale=3;}
	System.out.println("importance="+imp);
			   }

    public String getImportance() {
    return this.importance;
  }
     public int getImportanceScale() {
    return this.importanceScale;
  }   
}
