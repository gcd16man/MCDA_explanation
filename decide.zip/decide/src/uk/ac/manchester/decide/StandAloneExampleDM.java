/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * https://www.mozilla.org/en-US/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is "Simplenlg".
 *
 * The Initial Developer of the Original Code is Ehud Reiter, Albert Gatt and Dave Westwater.
 * Portions created by Ehud Reiter, Albert Gatt and Dave Westwater are Copyright (C) 2010-11 The University of Aberdeen. All Rights Reserved.
 *
 * Contributor(s): Ehud Reiter, Albert Gatt, Dave Westwater, Roman Kutlak, Margaret Mitchell, and Saad Mahamood.
 */
package uk.ac.manchester.decide;

//import simplenlg.org.junit.Ignore;
import simplenlg.features.Feature;
import simplenlg.features.Tense;
import simplenlg.framework.*;
import simplenlg.lexicon.Lexicon;
import simplenlg.lexicon.XMLLexicon;
import simplenlg.phrasespec.AdjPhraseSpec;
import simplenlg.phrasespec.NPPhraseSpec;
import simplenlg.phrasespec.PPPhraseSpec;
import simplenlg.phrasespec.SPhraseSpec;
import simplenlg.realiser.english.Realiser;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.util.ArrayList;
/**
 * @author gcdman
 */
//@Ignore
public class StandAloneExampleDM {

	/**
	 * %ant run -Darg1=C:/tmp/decide/data/parameters.xml
	 */
	public static void main(String[] args) {
	
			// template 1: criteria importance
			//e.g. 'what do the weights mean?'
		if (args[0]!= null && !args[0].trim().isEmpty()) {
		    NLGParameterReader nlgpr= new NLGParameterReader();
		    //nlgpr.setInputFilePath("C:/tmp/decide/data/parameters.xml");
		    //nlgpr.xmlParse("C:/tmp/decide/data/parameters.xml");
		    nlgpr.xmlParse(args[0]);
		    //runTemplate_1(args);
			
			    }
			
	}

    private static void runTemplate_1(String[] args){
	// e.g. '^high importance:Accessibility from US,Private sector|^medium importance:Availability of staff,Quality of life,Public sector|^low importance:Ease of set up and operations'
	if (args.length>=2 && args[0].equals("what-do-the-weights-mean")) {
	    if (args[1].contains(":")) {
		    System.out.println(args[1]);
		    String[] importance_list = args[1].split("\\|");
		    
		    for(String i: importance_list) {
			System.out.println(i);
			int colon = i.indexOf(":");
			String impLevel = i.substring(1,colon);
			String cr = i.substring(colon+1);
			System.out.println(impLevel);
			//System.out.println(cr);
			ArrayList<String> criteria = new  ArrayList<String>();
			String[] c_list = cr.split(",");
			for (String j:c_list) {
			    System.out.println(j);
			    criteria.add(j);
			}
		    }
		}
	}
	// test
	//System.out.println("You have rated the following criteria as highly important: Accessibility from US and Private sector. Whilst Availability of staff, Quality of life and Public sector are criteria considered to be of medium importance, Ease of set up and operations is of low importance. \n\nThis implies that the ranges of outcomes for important criteria such as the Private sector from 42 units to 96 units (i.e. from the worst to the best outcome) are more influential for the current choice than the ranges of outcomes for other less important criteria e.g. from 30 units to 90 units of Ease of set up and operations.");

    }
    

}
