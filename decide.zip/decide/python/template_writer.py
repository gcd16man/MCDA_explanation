"""
@author: G.Demetriou 
"""

import xml.etree.ElementTree as ET
import numpy as np
import random

def dump_parameters_template1(param_filename_path,
                              criteria_importance,
                              best_crit,
                              worst_crit,
                              max_best_crit_val,
                              min_best_crit_val,
                              max_worst_crit_val,
                              min_worst_crit_val):
    
    data = ET.Element('Template')
    data.set('id','1')
    params = ET.SubElement(data, 'Parameters')

    for imp, criteria in criteria_importance.items():
        print(imp, criteria)
        param=ET.SubElement(params, 'Parameter')
        param.set('name','criterion')
        param.set('quality','importance')
        param.set('value',imp.lower())
        for crit in criteria:
            print(crit)
            entity=ET.SubElement(param, 'Entity')
            entity.text = crit

    outcomes = ET.SubElement(data, 'OutcomeRanges')
    
    imp = ET.SubElement(outcomes, 'ImportantCriterion')
    imp.text=best_crit
    
    less_imp = ET.SubElement(outcomes, 'LessImportantCriterion')
    less_imp.text=worst_crit
    
    imp_best=ET.SubElement(outcomes, 'BestOutcomeImportantCriteriaRange')
    imp_best.text= str(max_best_crit_val)
    
    imp_worst=ET.SubElement(outcomes, 'WorstOutcomeImportantCriteriaRange')
    imp_worst.text= str(min_best_crit_val)

    less_imp_best=ET.SubElement(outcomes, 'BestOutcomeLessImportantCriteriaRange')
    less_imp_best.text= str(max_worst_crit_val)
    
    less_imp_worst=ET.SubElement(outcomes, 'WorstOutcomeLessImportantCriteriaRange')
    less_imp_worst.text= str(min_worst_crit_val)    
 

     
    # create a new XML file with the parameters
    mydata = ET.tostring(data,encoding="unicode")
    myfile = open(param_filename_path, "w")
    myfile.write(mydata)
    print(param_filename_path)
    return

def create_NLG_parameters_file(param_filename_path,
                               template_id,
                               criteria_importance,
                               criteria_importance_values_dict,
                               aname,
                               altz):
    print(aname,altz)
    if template_id=='1':  
        high= criteria_importance['High']
        r = random.randint(0, len(high)-1)
        best_crit=high[r]

        low=criteria_importance['Low']
        r = random.randint(0, len(low)-1)
        worst_crit=low[r]

        print('High:'+best_crit+' Low:'+worst_crit)

        #find ranges of criteria scores
        best_crit_values = criteria_importance_values_dict[best_crit]      
        max_best_crit_val = np.max(best_crit_values)
        min_best_crit_val = np.min(best_crit_values)
        
        worst_crit_values = criteria_importance_values_dict[worst_crit]
        max_worst_crit_val = np.max(worst_crit_values)
        min_worst_crit_val = np.min(worst_crit_values)
        
        
        dump_parameters_template1(param_filename_path,
                                  criteria_importance,
                                  best_crit,
                                  worst_crit,
                                  max_best_crit_val,
                                  min_best_crit_val,
                                  max_worst_crit_val,
                                  min_worst_crit_val
                                  )
    return 

def temp_find_best_worst():
    #best_alt = next(iter(mean_rank_dict))
        #worst_alt=list(mean_rank_dict.keys())[-1]
        #print(best_alt, worst_alt)

        #bi=aname.index(best_alt)
        #print(altz[bi])
        #max_best_alt_val = np.max(altz[bi])
        #min_best_alt_val = np.min(altz[bi])
        #print(max_best_alt_val, min_best_alt_val)

        #wi=aname.index(worst_alt)
        #print(altz[wi])
        #max_worst_alt_val = np.max(altz[wi])
        #min_worst_alt_val = np.min(altz[wi])
        #print(max_worst_alt_val, min_worst_alt_val)
    return
