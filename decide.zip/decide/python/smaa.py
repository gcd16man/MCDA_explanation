"""
@author: @G.Demetriou adapted code by @Theo Stewart
SMAA analysis
"""
import numpy as np

# nc = number of criteria
# na = number of alternatives

def SMAAanal(SMREP,zmat,cimport,cprec,gpatt,nc,na,primalt=-1,secalt=-1):
    ##  and conditions for optimality of primalt if specified (>=0) (CASE 1)
    ##  and paired comparison of primalt and secalt if both specified  (CASE2)
    case=0
    if primalt>-1:
        case =1
        if secalt>-1:
            case=2

    # Initialize arrays of counts
    rnkposf=np.zeros((na,na),dtype=int)
    primoptf=0
    primoptw=np.zeros((nc),dtype=float)
    primoptpv=np.zeros((4,nc),dtype=float)
    compf=np.zeros((3),dtype=int)
    compw=np.zeros((nc,3),dtype=float)
    comppv=np.zeros((4,nc,3),dtype=float)
    
    #  Set up "alpha" vector for weight distribution
    walph=np.ones((nc),dtype=float)
    for i in range(nc):
        if cimport[i]=='high':
            walph[i]=EWTR
        elif cimport[i]=='med':
            walph[i]=SEWTR
    s=sum(walph)
    walph=[nc*x/s for x in walph]
         
    # Now start monte carlo iterations
    for r in range(SMREP):
        # perturb data to simulate precision errors
        ztmp=np.empty((na,nc))
        for i in range(na):
            for j in range(nc):
                ztmp[i,j]=zmat[i,j]+(2*np.random.random(1)-1)*cprec[j]
        # and restandardize the perturbed data
        zmx=np.amax(ztmp,0)
        zmn=np.amin(ztmp,0)
        zrng=zmx-zmn
        zpert=np.empty((na,nc),dtype=float)
        for i in range(nc):
            zpert[:,i]=4*(ztmp[:,i]-zmn[i])/zrng[i]
         
         
        ## Generate weights randomly in bounds
        wts=np.random.dirichlet(walph,1)
        wts=np.ndarray.flatten(wts)   ## to make it a vector
        
        ## Generate gaps for partial value functions
        gapd=np.random.dirichlet((1,1,1,1),nc) # each uniform on simplex
        gapd=np.transpose(gapd)
        # adjust for pattern where specified
        for i in range(nc):
            if gpatt[i]=='linear':
                gapd[:,i]=[0.25,0.25,0.25,0.25]
            elif gpatt[i]=='decreasing':
                gapd[:,i]=-np.sort(-gapd[:,i])
            elif gpatt[i]=='increasing':
                gapd[:,i]=np.sort(gapd[:,i])
            elif gpatt[i]=='midrange':
                if gapd[0,i]>gapd[1,i]:
                    gapd[0,i],gapd[1,i]=gapd[1,i],gapd[0,i]
                if gapd[3,i]>gapd[2,i]:
                    gapd[3,i],gapd[2,i]=gapd[2,i],gapd[3,i]
                    
        # Generate values for alternatives
        vfp=np.zeros([na,nc],dtype=float)
        
        for i in range(na):
            for j in range(nc):
                for k in range(4):
                    zdel=zpert[i,j]-k
                    if zdel<1:
                        vfp[i,j]+=zdel*gapd[k,j]
                        break
                    vfp[i,j]+=gapd[k,j]
        
        Vf=np.sum(np.transpose([wts[j]*vfp[:,j] for j in range(nc)]),1)
        rposa=np.argsort(-Vf)    ## altern in each rank position
        ranks=np.argsort(rposa)  ## ranks  of each alternative
        
        if case==0:
            for i in range(na):
                rnkposf[i,ranks[i]]+=1
        if case==1:
            if ranks[primalt]==0:
                primoptf+=1
                primoptw=primoptw+wts
                primoptpv=primoptpv+gapd
        if case==2:
            if Vf[primalt]>Vf[secalt]+CDIFF:  ## prim sign better
                c=0
            elif Vf[primalt]>Vf[secalt]-CDIFF:  ## indifference
                c=1
            else:      ## sec sign better
                c=2
            compf[c]+=1
            for j in range(nc):
                compw[j,c]+=wts[j]
            for k in range(4):
                for j in range(nc):
                    comppv[k,j,c]+=gapd[k,j]
        
    if case==0:
        rnkposf=rnkposf/SMREP
        return rnkposf
    elif case==1:
        if primoptf>0:
            primoptw=primoptw/primoptf
            primoptpv=primoptpv/primoptf
        primoptf=primoptf/SMREP
        return primoptf,primoptw,primoptpv
    else:          ## case 2
        for c in range(3):
            if compf[c]>0:
                compw[:,c]=compw[:,c]/compf[c]
                comppv[:,:,c]=comppv[:,:,c]/compf[c]
        compf=np.array(compf,dtype=float)
        compf=compf/SMREP
        return compf,compw,comppv
