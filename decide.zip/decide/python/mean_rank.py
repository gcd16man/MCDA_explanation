"""
@author: G.Demetriou 
Mean rank
"""
import numpy as np
#import collections

# data -> type: numpy.ndarray

def mean_rank(data, aname):
   # print(aname)
   # print(data)
    name_to_rank = {}
    (sizey,sizex) = data.shape
    mean_rank_score = np.zeros((sizey),dtype=float)
    for i in range(sizey):
        k=0
        score=0
        for j in range(sizex):
            k=j+1
            score=score+data[i,j]*k
        mean_rank_score[i]=score
        #print(aname[i], '=', mean_rank_score[i])
        name_to_rank[aname[i]]=mean_rank_score[i]
    sorted_name_to_rank = sorted(name_to_rank.items(), key=lambda kv: kv[1])
    sorted_name_to_mean_rank=dict(sorted_name_to_rank)
    #print(sorted_name_to_mean_rank)
    return sorted_name_to_mean_rank
    
