"""
@author: G.Demetriou adapted code by @Theo Stewart
Draft of Explanation System modules
"""

import pandas as pd
import numpy as np
import collections

from smaa import SMAAanal
from mean_rank import mean_rank

class DataExploration:

    def __init__(self):
                 self.SMREP=1000 ## Number of SMAA monte carlo repetitions
                 self.EWTR=4     ## Ratio of expected weights betweeen high aand low groups
                 self.SEWTR=2         ## Square root for medium weight position
                 self.CDIFF=0.025     ## Difference viewed as insignificant in paired compared comparisons
                 self.df = None ## pandas dataframe
                 self.crit = None ## criteria series
                 self.cimport = None ##importance classes
                 self.cdirection = None ## direction values
                 self.cprec = None ## precision values
                 self.gpatt = None ## pattern values
                 self.ccurve = None ## cruve shapes
                 self.aname = [] ## alternatives
                 self.altz = [] ## alternative scores (m x n)
                 self.cimport_values={}
                 
    def explore_data(self,data_path,param_path,template_id):
        #print(data_path)
        welcome_sheet = pd.read_excel(data_path, sheet_name='Welcome', index_col=None, na_values=['NaN'], usecols="A:G")

        column_name = 'EXPLANATION SYSTEMS FOR DISCRETE CHOICE MCDA'
        self.df = pd.DataFrame(welcome_sheet)
        return

    def read_criteria(self):
        # read criteria labels
        self.crit=self.df.iloc[2][1:]
        c_len=len(self.crit)
        for j in range(c_len):
            k=j+1
            v_list=[]
            c = self.crit[j]
            for i in range(len(self.df)):
                if i>=8 and i<=14:
                    v_list.append(self.df.iloc[i][k])
            self.cimport_values[c]=v_list
            print(c, v_list)
                
        return self.crit

    def get_criteria_importance_values(self):
        return self.cimport_values
    
    def read_importance_classes(self):
        self.cimport=self.df.iloc[4][1:]       
        return self.cimport

    def read_direction_values(self):
        self.cdirection=self.df.iloc[3][1:]
        return self.cdirection
    
    def read_precision_values(self):
        self.cprec=[float(x) for x in self.df.iloc[5][1:]]
        #print(self.cprec)
        return self.cprec

    def read_shape_values(self):
        self.gpatt=self.df.iloc[6][1:]
        #print(self.gpatt)
        return self.gpatt

    def read_curvature_values(self):
        self.ccurve=[float(x) for x in self.df.iloc[7][1:]]
        return self.ccurve
    
    def read_alternatives_names_scores(self):
        ## Alternatives
        for i in range(len(self.df)):
            #    print(i, self.df.iloc[i][0])
            if i>=8 and i<=14:
                self.aname.append(self.df.iloc[i][0])
                drow=[float(z) for z in self.df.iloc[i][1:]]
                self.altz.append(drow)
                
        return self.aname,self.altz

    def standardize_values(self,rangeMin,rangeMax):
        ## Standardize z-values to rangeMin-rangeMax increasing
        self.altz=np.array(self.altz)
        nc=len(self.crit)   ## number of criteria

        na=len(self.aname)  ## number of alternatives
        
        zmx=np.amax(self.altz,0)
        zmn=np.amin(self.altz,0)
        zrng=zmx-zmn
        zmat=np.empty((na,nc),dtype=float)
        for i in range(nc):
            if self.cdirection[i]=='Max':
                zmat[:,i]=100*(self.altz[:,i]-zmn[i])/zrng[i]
            elif self.cdirection[i]=='min':  
                zmat[:,i]=100*(zmx[i]-self.altz[:,i])/zrng[i]
            else:     ## defaulting to categorical
                zmat[:,i]=self.altz[:,i]
        #for i in range(na):
        #    print(self.aname[i],zmat[i,:])
        return zmat
    
    def get_important_criteria_classes(self):
        #returns dict e.g. {'high': [London,Paris],...}
        criteria_importance = {}
        for c in range(len(self.crit)):
           # print(self.crit[c])
           # print(self.cimport[c])
            iv = self.cimport[c]
            #print(iv)
            if iv in criteria_importance:
                v = criteria_importance.get(iv)
                v.append(self.crit[c])                
                criteria_importance[iv]=v
            else:
                criteria_importance[iv]=[self.crit[c]]       
        #print(criteria_importance)      
        return criteria_importance

    def run_smaa_analysis(self,zmat):
        nc = len(self.crit)   ## number of criteria
        na = len(self.aname)
        #result_smaaanal = SMAAanal(SMREP,zmat,cimport,cprec,gpatt,nc,na,-1,-1)
        smaa_result =SMAAanal(self.SMREP,
                              zmat,
                              self.cimport,
                              self.cprec,
                              self.gpatt,
                              nc,na,
                              -1,-1)
        print(smaa_result)
        return smaa_result

 
        
