"""
@author: G.Demetriou 
"""

def extract_parameters_template1():
    data = ET.Element('data')
    items = ET.SubElement(data, 'items')
    item1 = ET.SubElement(items, 'item')
    item2 = ET.SubElement(items, 'item')
    item1.set('name','item1')
    item2.set('name','item2')
    item1.text = 'item1abc'
    item2.text = 'item2abc'

    # create a new XML file with the parameters
    mydata = ET.tostring(data,encoding="unicode")
    myfile = open(param_filename_path, "w")
    myfile.write(mydata)
    return

def extract_NLG_parameters(template_id,
                           mean_rank_dict):
    #print(mean_rank_dict)
    if template_id=='1':
        best_alt = next(iter(mean_rank_dict.keys()))
        print(best_alt)
        #dump_parameters_template1(param_filename_path)
    return 

