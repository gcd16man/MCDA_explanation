"""
@author: G.Demetriou adapted code by @Theo Stewart
Draft of Explanation System modules
"""

import sys
import os
import pathlib as p
import pandas as pd
import numpy as np

#import configparser

from parameters_extractor import extract_NLG_parameters
from template_writer import create_NLG_parameters_file
from data_explorer import explore_data
from data_exploration import DataExploration
from mean_rank import mean_rank

def main():
    this_path = os.path.realpath(__file__)
    print(this_path)
    script_path = p.Path(this_path)
    print(script_path.parent.absolute())
    pid = os.getpid()
    print("Process id: ", pid)
    args = sys.argv[1:]
    data_path=''
    param_path=''
    template_id = ''
    param_filename='parameters'+str(pid)+'.xml'
    
    print(param_filename)
    #   args[0] is '-data_path' and args[1] is full path to ms excel spreadsheet inc. filename
    # e.g. C:\tmp\decide\data\MAVTExplanationV01.xlsm
    #   args[2] is '-param_path' and args[3] is full path to parameters folder
    # e.g. C:\tmp\decide\python\parameters
    # args[4] is 'template_id' and args[5] is the id of template for generating explanations
    # e.g. -template 2
    if len(args) == 6:
        if (args[0] == '-data_path'):
            data_path=args[1]
            #print(data_path)
            path = p.Path(data_path)
            if not(path.exists()) or not(path.stat().st_size > 0):
                sys.exit("Error: Invalid data path or data file is empty")
            
        if (args[2] == '-param_path'):
            param_path=args[3]
            print(param_path)
            path = p.Path(param_path)
            if not path.exists():
                print("Error: Non-existent path:",param_path)
                try:
                    os.makedirs(param_path,exist_ok = True)
                    print("Path '%d' has been created!" %param_path)
                except OSError as error:
                    print("Path '%d' can not be created" %param_path)
                    sys.exit()
            param_filename_path=param_path + '\\' + param_filename
            print(param_filename_path)
        if (args[4] == '-template_id'):
            template_id=args[5]
            #print(template_id)
            if not template_id:
                sys.exit("Error: Invalid template id")
    else:
         sys.exit("Error: invalid input!\n\
         Usage: %py decide-main.py -data_path [absolute path of data file(excel)] -param_path [absolute path of parameters file] -template_id [template id no]")
         

    #extract_NLG_parameters(template_id,
    #                       mean_rank_dict)
    
    #get_important_criteria_classes(crit,altz)
    data_explorer = DataExploration()
    data_explorer.explore_data(data_path,param_path,template_id)
   
    (aname,altz) = data_explorer.read_alternatives_names_scores()

    print(aname,altz)
    data_explorer.read_shape_values()
    data_explorer.read_precision_values()
    data_explorer.read_criteria()
    data_explorer.read_importance_classes()
    data_explorer.read_direction_values()
    
    criteria_importance = data_explorer.get_important_criteria_classes()
    print(criteria_importance)

    # get z-values
    z_scores = data_explorer.standardize_values(0,100)

    result_smaaanal = data_explorer.run_smaa_analysis(z_scores)
    # find mean_ranks
    #mean_rank_dict, crit, altz=explore_data(data_path,param_path,template_id)
    
    #mean_rank_dict = mean_rank(result_smaaanal,aname)
    #print(mean_rank_dict)
    criteria_importance_values_dict = data_explorer.get_criteria_importance_values()
    print("====",criteria_importance_values_dict)
    if template_id=='1':
        create_NLG_parameters_file(param_filename_path,
                                   template_id,
                                   criteria_importance,
                                   criteria_importance_values_dict,
                                   aname,
                                   altz)
main()
